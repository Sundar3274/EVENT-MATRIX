import os
from flask import Flask, request, render_template, send_file, flash, redirect, url_for
from googleapiclient.http import MediaFileUpload
from google.oauth2 import service_account
from googleapiclient.discovery import build
import io
from fpdf import FPDF

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'  # Folder to save files before uploading to Google Drive
app.secret_key = 'supersecretkey'

# Google Drive API setup
SCOPES = ['https://www.googleapis.com/auth/drive']
SERVICE_ACCOUNT_FILE = 'D:/Miniproject/event-app/credentials.json'
credentials = service_account.Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)
drive_service = build('drive', 'v3', credentials=credentials)

# Google Drive folder ID where files will be uploaded
GOOGLE_DRIVE_FOLDER_ID = '1KfbjLtzKXkMS05ovGn6GzxcGR7DeakUs'


@app.route('/', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        # Handle event inputs
        event_name = request.form.get('event_name', 'N/A')
        event_date = request.form.get('event_date', 'N/A')
        event_description = request.form.get('event_description', 'N/A')

        # Create a dictionary to hold the event details
        event_data = {
            'Event Name': event_name,
            'Event Date': event_date,
            'Description': event_description
        }

        # Handle file uploads (images) and upload only images to Google Drive
        image_files = request.files.getlist("image_files")
        for image in image_files:
            image_path = os.path.join(app.config['UPLOAD_FOLDER'], image.filename)
            image.save(image_path)  # Save image locally

            # Upload image to Google Drive
            file_id = upload_to_drive(image.filename, image_path)
            if file_id:
                flash(f"Image {image.filename} uploaded to Google Drive. File ID: {file_id}", "success")
            else:
                flash(f"Failed to upload image {image.filename}", "error")

        # Generate the PDF from the event data and serve it in-memory
        pdf_bytes_io = create_pdf(event_data)

        # Return the PDF for the user to view in the browser
        return send_file(
            pdf_bytes_io,
            mimetype='application/pdf',
            as_attachment=False,
            download_name='event_summary.pdf'
        )

    return render_template('index.html')


def create_pdf(event_data):
    """Generate a PDF with event details and return it as an in-memory file."""
    pdf = FPDF()
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()

    # Add event details to the PDF
    pdf.set_font('Arial', 'B', 16)
    pdf.cell(200, 10, txt="Event Summary", ln=True, align="C")

    pdf.set_font('Arial', '', 12)
    for key, value in event_data.items():
        pdf.cell(200, 10, txt=f"{key}: {value}", ln=True)

    # Save the PDF to an in-memory buffer
    pdf_bytes_io = io.BytesIO()  # Create a BytesIO buffer
    pdf.output(dest='S').encode('latin1')  # Output to string in bytes, encoding for FPDF compatibility
    pdf_bytes_io.write(pdf.output(dest='S').encode('latin1'))  # Write the PDF content to BytesIO
    pdf_bytes_io.seek(0)  # Move the pointer to the beginning of the file

    return pdf_bytes_io


def upload_to_drive(file_name, file_path):
    """Uploads a file to Google Drive and stores it in the specific folder."""
    try:
        # File metadata with the specific folder ID
        file_metadata = {
            'name': file_name,
            'parents': [GOOGLE_DRIVE_FOLDER_ID]  # Upload to the specified folder
        }
        media = MediaFileUpload(file_path, resumable=True)  # Set resumable=True to handle large files

        # Create a file in Google Drive
        uploaded_file = drive_service.files().create(
            body=file_metadata,
            media_body=media,
            fields='id'
        ).execute()

        # Return the file ID upon success
        file_id = uploaded_file.get('id')
        if file_id:
            print(f"File uploaded successfully: {file_id}")
            # Remove the file locally after successful upload
            if os.path.exists(file_path):
                os.remove(file_path)  # Safely remove the file after upload
            return file_id  # Return file ID upon success
        else:
            return None  # Return None in case of failure
    except Exception as e:
        print(f"An error occurred while uploading to Google Drive: {e}")
        return None


if __name__ == '__main__':
    # Ensure the upload folder exists
    if not os.path.exists(app.config['UPLOAD_FOLDER']):
        os.makedirs(app.config['UPLOAD_FOLDER'])

    app.run(debug=True)
